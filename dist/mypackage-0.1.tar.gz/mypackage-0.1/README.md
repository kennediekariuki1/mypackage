# mypackage
This library was created as an axample of how to publish your own Python package.

# How to install
....